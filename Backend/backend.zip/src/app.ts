import express from "express";
import router from "./route/route";

const app = express();

app.use(express.json());

// base route
app.use("/api", router);

export default app;