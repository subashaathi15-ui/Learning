import { Request, Response } from "express";
import { db } from "../../db";
import { users } from "../../db/schema/user/user.schema";

export const createUser = async (req: Request, res: Response) => {
  const { name, age, email } = req.body;

  // 1. check if data is missing
  if (!name || !age || !email) {
    return res.send("Please send name, age, email");
  }

  // 2. save in database
  await db.insert(users).values({
    name: name,
    age: Number(age),
    email: email,
  });

  // 3. send response
  res.send("User created successfully");
};