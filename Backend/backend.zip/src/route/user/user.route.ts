import express from "express"; import { createUser } from "../../controllers/user/user.controller"; 

const userRouter = express.Router(); // POST /users 

userRouter.post("/", createUser); 

export default userRouter;