import express from "express"; 
import userRouter from "./user/user.route";

const router = express.Router(); // group routes 

router.use("/users", userRouter);

export default router;